# SHIVANK AI — Voice-first Personal Operator (v0.2)

**Founder:** Shivank Dwivedi  
**Target setup:** Android + Windows/macOS/Linux PC, one voice-first dashboard.

This is an original starter architecture informed by public open-source projects. It does not bundle or relicense upstream source code.

## What is working in this ZIP

- Responsive dashboard for Android and desktop browsers.
- Browser voice input (Web Speech API where supported) and spoken responses (Speech Synthesis).
- Gemini, Groq and OpenRouter adapters, with `auto` provider fallback across configured providers.
- Multi-agent planning/research/build/automation-review pipeline and SQLite task history.
- Direct music search/open on the current device using YouTube Music web links.
- Optional paired desktop companion that polls the server and executes a **small allow-list**: media play/pause, next/previous, volume up/down/mute, and opening selected HTTPS sites (YouTube, YouTube Music, Spotify, GitHub, Google, Gmail).
- PC companion uses a pairing token; it does not expose a general-purpose shell or arbitrary file access.
- Optional HTTP Basic dashboard password.

## What is not implemented yet

This is a useful v0.2 foundation, not a fully autonomous Jarvis replacement. It does **not** yet:

- tap arbitrary Android apps or read/control the whole Android screen;
- control arbitrary PC applications, run shell commands, or freely edit/delete files;
- send WhatsApp/email messages or operate logged-in websites;
- run unattended background schedules or keep working when the server/companion is offline;
- guarantee voice recognition in every browser/device (Chrome is recommended; microphone permission and HTTPS may be required).

The dashboard can be opened on both phone and PC. To control the PC from the phone, the backend must be reachable by both devices and the PC companion must be running. For a local network setup, run the server on the PC and open its LAN URL on the phone. For remote use, deploy the backend with HTTPS and run the companion on the PC.


## Android-only setup (run directly on your phone)

This mode runs the Python backend locally inside Termux; no PC or cloud host is required for the phone's own dashboard and AI tasks. It is a self-hosted local setup, not an installable APK.

1. Install **Termux** from its official F-Droid or GitHub source (avoid the outdated Play Store build).
2. Download and extract this ZIP into a folder accessible to Termux. If you downloaded it to Android storage, in Termux run `termux-setup-storage`, then copy/extract the project into `$HOME/shivank_ai_agent`.
3. In Termux, run:

```bash
cd ~/shivank_ai_agent
bash termux/setup.sh
nano .env
```

4. Add newly rotated keys to `GEMINI_API_KEY`, `GROQ_API_KEY`, and `OPENROUTER_API_KEY` in `.env`. Do not paste keys into chat or GitHub. Set a private `APP_PASSWORD` if desired.
5. Start the agent:

```bash
bash termux/start.sh
```

6. Open `http://127.0.0.1:8000` in Chrome on the same phone. Allow microphone access and keep Termux running while using SHIVANK AI. For voice recognition, Chrome support and Android microphone permission are required.

**Android limits in this build:** voice chat and AI tasks run on the phone; music search opens YouTube Music in the browser/app. This web dashboard cannot yet tap arbitrary Android apps, read the screen, or reliably control system volume/next/pause for other apps. Full native Android control needs a separate Android app/Accessibility Service with explicit user-granted permissions.

To stop the server, return to Termux and press `CTRL+C`. Android may stop background Termux processes to save battery; disable battery optimization for Termux if you need longer sessions.

## Quick setup on Windows PC

1. Install Python 3.11+.
2. Extract this ZIP on the PC.
3. Open PowerShell in the extracted folder and run:

```powershell
py -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
Copy-Item .env.example .env
```

4. Edit `.env`. Add **newly rotated** provider keys to `GEMINI_API_KEY`, `GROQ_API_KEY`, and `OPENROUTER_API_KEY`. Set a strong `APP_PASSWORD` and a random `DEVICE_AGENT_TOKEN` (at least 32 random characters). Never put secrets in GitHub or the ZIP.
5. Start the server:

```powershell
uvicorn app.main:app --host 0.0.0.0 --port 8000
```

6. On the same PC, open a second PowerShell window in the folder. Set the same pairing token and start the companion:

```powershell
$env:DEVICE_AGENT_TOKEN="PASTE_THE_SAME_RANDOM_TOKEN_HERE"
.\.venv\Scripts\python.exe desktop_agent\companion.py --server http://127.0.0.1:8000
```

7. On the PC open `http://127.0.0.1:8000`. On Android connected to the same Wi-Fi, open `http://PC-LAN-IP:8000` (find the PC IPv4 address with `ipconfig`). Use the dashboard password when prompted. Android microphone access works best over HTTPS; local HTTP may be blocked by some browsers.

## Cloud / remote setup

Deploy the backend using Docker or a Python host with persistent storage. Configure all environment variables in the host's **Secrets / Environment Variables** panel. Set `APP_PASSWORD` and `DEVICE_AGENT_TOKEN`; do not expose either in frontend code. Run the desktop companion on the PC with the public HTTPS server URL and the same `DEVICE_AGENT_TOKEN` environment variable. Restrict the server to your own account/network where possible.

```bash
pip install -r requirements.txt
uvicorn app.main:app --host 0.0.0.0 --port "$PORT"
```

## Voice examples

- “Play Arijit Singh songs” — opens a YouTube Music search on the current device.
- Select **Paired PC** and say “next song”, “pause music”, “volume up” — sends an allow-listed media-key action to the PC companion.
- Select **Paired PC** and say “open GitHub” — opens GitHub on the PC.
- “Research the best open-source Android AI agents” — runs the multi-agent AI task pipeline.

## Security model

- The API keys are read only from server-side environment variables; the dashboard never returns key values.
- The desktop companion accepts only predefined action types and approved HTTPS hostnames. No LLM-generated shell commands are executed.
- Keep `APP_PASSWORD` and `DEVICE_AGENT_TOKEN` private. Use HTTPS for internet deployment. Rotate any key that has ever been pasted into a chat, issue, screenshot, or repository.
- Media actions depend on OS support and the active media session. Windows uses media virtual keys; macOS currently supports Music app transport keys; Linux expects `playerctl` and `pactl` where relevant.

## API

- `GET /api/health`
- `GET /api/config`
- `GET /api/tasks`
- `POST /api/run` — `{ "task": "...", "provider": "auto|gemini|groq|openrouter" }`
- `POST /api/command` — `{ "command": "pause music", "target": "this_device|pc|both" }`
- `GET /api/device/next` — desktop companion polling (pairing token required)
- `POST /api/device/{job_id}/result` — companion result (pairing token required)

## Tests

```bash
python -m compileall app desktop_agent
pytest -q
```

## Open-source projects to study / integrate carefully

- [OpenHands Software Agent SDK](https://github.com/OpenHands/software-agent-sdk) — agent runtime and coding/workspace patterns (MIT).
- [CrewAI](https://github.com/crewAIInc/crewAI) — role-based multi-agent orchestration and Flows (MIT).
- [Browser Use](https://github.com/browser-use/browser-use) — browser interaction agent library (MIT; inspect current dependencies and deployment model).
- [Open Interpreter](https://github.com/OpenInterpreter/open-interpreter) — local computer interaction ideas; do not enable unrestricted execution by default.
- [n8n](https://github.com/n8n-io/n8n) — workflow automation platform; source-available Sustainable Use License, not MIT; check terms before commercial use.

This project uses architectural ideas only. Review upstream code and licenses independently before incorporating any source code.
